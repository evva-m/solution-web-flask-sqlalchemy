from data import db_session
from data.users import User
from data.jobs import Jobs
from flask import Flask, render_template, url_for


app = Flask(__name__)


@app.route('/index')
def index(title):
    return render_template('base.html', title=title)


@app.route('/')
def works_log():
    global db_sess
    data = [[j.job, '{} {}'.format(db_sess.query(User).filter(User.id == j.team_leader).first().name,
                                   db_sess.query(User).filter(User.id == j.team_leader).first().surname),
             f'{j.work_size} hours', j.collaborators, j.is_finished] for j in db_sess.query(Jobs).all()]
    return render_template('works_log.html',
                           css_url=url_for('static', filename='css/style.css'), works=data)


if __name__ == '__main__':
    db_session.global_init('db/mars_explorer.db')
    db_sess = db_session.create_session()
    app.run(port=8080, host='127.0.0.1')
