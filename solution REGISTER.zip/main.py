from data import db_session
from data.users import User
from data.jobs import Jobs
from flask_login import LoginManager, login_user
import flask_login
from flask import Flask, render_template, redirect, url_for, request
from flask_wtf import FlaskForm
from wtforms import PasswordField, BooleanField, SubmitField, EmailField, StringField, IntegerField
from wtforms.validators import DataRequired
from bcrypt import checkpw, hashpw, gensalt

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).filter(User.id == user_id).first()


class RegisterForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    r_password = PasswordField('Повторите пароль', validators=[DataRequired()])
    surname = StringField('Фамилия', validators=[DataRequired()])
    name = StringField('Имя', validators=[DataRequired()])
    age = IntegerField('Полных лет', validators=[DataRequired()])
    pos = StringField('Должность', validators=[DataRequired()])
    spec = StringField('Специальность', validators=[DataRequired()])
    address = StringField('Адрес', validators=[DataRequired()])
    submit = SubmitField('Зарегистрироваться')


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class AddWork(FlaskForm):
    leader_id = IntegerField('ID лидера команды', validators=[DataRequired()])
    job = StringField('Название работы', validators=[DataRequired()])
    work_size = IntegerField('Объем работы в часах', validators=[DataRequired()])
    collaborators = StringField('ID работников через запятую с пробелом', validators=[DataRequired()])
    is_finished = BooleanField('Окончена ли работа?')
    submit = SubmitField('Добавить работу')


@app.route('/')
def works_log():
    global db_sess
    data = [[j.job, '{} {}'.format(db_sess.query(User).filter(User.id == j.team_leader).first().name,
                                   db_sess.query(User).filter(User.id == j.team_leader).first().surname),
             f'{j.work_size} hours', j.collaborators, j.is_finished] for j in db_sess.query(Jobs).all()]
    return render_template('works_log.html',
                           css_url=url_for('static', filename='css/style.css'), works=data,
                           current_user=flask_login.current_user)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():

        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == str(form.email.data)).first()
        if user and checkpw(bytes(form.password.data, 'utf-8'), user.hashed_password):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form, css_url=url_for('static', filename='css/style.css'))
    return render_template('login.html', title='Авторизация', form=form,
                           css_url=url_for('static', filename='css/style.css'))


@app.route('/addjob', methods=['GET', 'POST'])
def addjob():
    form = AddWork()
    if form.validate_on_submit() or request.method == 'POST':
        try:
            newjob = Jobs(team_leader=form.leader_id.data, job=form.job.data, work_size=form.work_size.data,
                          collaborators=form.collaborators.data, is_finished=form.is_finished.data)
            db_sess.add(newjob)
            db_sess.commit()
            return redirect('/')
        except:
            return render_template('add_job.html', title='Adding a job', form=form,
                                   css_url=url_for('static', filename='css/style.css'), message='Неверные данные')
    return render_template('add_job.html', title='Adding a job', form=form,
                           css_url=url_for('static', filename='css/style.css'))


@app.route('/register', methods=['GET', 'POST'])
def reg():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data == form.r_password.data:
            newu = User(name=form.name.data, surname=form.surname.data, position=form.pos.data, age=form.age.data,
                        speciality=form.spec.data, address=form.address.data, email=form.email.data,
                        hashed_password=hashpw(bytes(form.password.data, 'utf-8'), salt=gensalt()))
            db_sess.add(newu)
            db_sess.commit()
            return redirect('/')
        return render_template('register.html', form=form, title='Registration',
                               css_url=url_for('static', filename='css/style.css'), message='Пароль не совпадает')
    return render_template('register.html', form=form, title='Registration',
                           css_url=url_for('static', filename='css/style.css'))


if __name__ == '__main__':
    db_session.global_init("db/mars_explorer.db")
    db_sess = db_session.create_session()

    app.run(port=8080, host='127.0.0.1')
